package com.cg.wallet.exceptions;

public class InvalidInputException extends RuntimeException {

	public InvalidInputException(String msg) {
		super(msg);
	}
}
